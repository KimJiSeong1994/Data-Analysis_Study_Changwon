
# coding: utf-8

# In[1]:

# render.py
from ..sound.echo import echo_test

def render_test():
    print ("render")
    echo_test()

# In[ ]:



