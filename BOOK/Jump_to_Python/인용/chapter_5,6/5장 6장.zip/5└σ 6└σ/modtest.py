
# coding: utf-8

# In[4]:

import os


# In[8]:

os.chdir("C:/Users/SAMSUNG/Downloads/지성 스터디")


# In[ ]:




# In[ ]:




# In[9]:

# modtest.py
import mod2
result = mod2.add(3, 4)
print(result)


# In[ ]:




# In[ ]:




# In[ ]:



