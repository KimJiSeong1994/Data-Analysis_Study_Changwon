
# coding: utf-8

# In[4]:

import os


# In[8]:

os.chdir("C:/Users/SAMSUNG/Downloads/지성 스터디")


# In[ ]:




# In[ ]:




# In[9]:

# modtest.py
import mod2
result = mod2.add(3, 4)
print(result)


# In[10]:

import sys


# In[11]:

sys.path


# In[12]:

sys.path.append("C:/Users/SAMSUNG/Downloads/지성 스터디/mymod")


# In[13]:

sys.path


# In[14]:

import mod2
result = mod2.add(3, 4)


# In[ ]:



