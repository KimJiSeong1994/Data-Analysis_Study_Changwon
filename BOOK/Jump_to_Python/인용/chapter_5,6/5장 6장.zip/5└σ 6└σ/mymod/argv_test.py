
# coding: utf-8

# In[1]:

import sys
print(sys.argv)


# In[ ]:



