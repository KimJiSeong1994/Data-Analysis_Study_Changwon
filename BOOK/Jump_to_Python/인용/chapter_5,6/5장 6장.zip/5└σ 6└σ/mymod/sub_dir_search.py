
# coding: utf-8

# In[1]:

def search(dirname):
    print (dirname)

search("c:/")


# In[ ]:



