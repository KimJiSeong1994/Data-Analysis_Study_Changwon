#Q10_os_module.py

import os

os.chdir("C:\Test\JT_Python")
a10=os.popen("dir")
print(a10.read())
