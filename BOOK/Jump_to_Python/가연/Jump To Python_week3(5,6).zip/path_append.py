# path_append.py

import sys
sys.path.append("C:/Test/JT_Python")
