# modtest.py
import mod2
result=mod2.add(3,4)
print(result)
