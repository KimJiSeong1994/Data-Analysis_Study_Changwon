# argv_test.py

import sys
print(sys.argv)
