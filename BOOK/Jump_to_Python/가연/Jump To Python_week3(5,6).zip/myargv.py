#myargv.py

def add(argv):
    result=0
    for i in argv:
        result=i+result
        
    print(result)
